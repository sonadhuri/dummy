A Pen created at CodePen.io. You can find this one at https://codepen.io/imilenig/pen/rPVyaw.

 Learn how to create an accordion (collapsible content) only with CSS and HTML. Accordions are useful when you want to toggle between hiding and showing large amount of content. This method is not working in IE and Edge.